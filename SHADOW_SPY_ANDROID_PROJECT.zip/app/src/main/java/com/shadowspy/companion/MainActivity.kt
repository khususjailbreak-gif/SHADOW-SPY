package com.shadowspy.companion

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var cameraStatus: TextView
    private var imageCapture: ImageCapture? = null
    private var lens = CameraSelector.LENS_FACING_BACK

    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera()
        else cameraStatus.text = "Izin kamera belum diberikan."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        cameraStatus = findViewById(R.id.cameraStatus)

        refreshDeviceInfo()
        findViewById<Button>(R.id.rearButton).setOnClickListener {
            lens = CameraSelector.LENS_FACING_BACK
            requestCameraAndStart()
        }
        findViewById<Button>(R.id.frontButton).setOnClickListener {
            lens = CameraSelector.LENS_FACING_FRONT
            requestCameraAndStart()
        }
        findViewById<Button>(R.id.captureButton).setOnClickListener { capturePhoto() }
        findViewById<Button>(R.id.usageButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        updateUsageInfo()
    }

    override fun onResume() {
        super.onResume()
        refreshDeviceInfo()
        updateUsageInfo()
    }

    private fun refreshDeviceInfo() {
        val battery = getSystemService(BATTERY_SERVICE) as BatteryManager
        val level = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val device = "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}"
        findViewById<TextView>(R.id.deviceInfo).text =
            "PERANGKAT\n$device\nAndroid ${android.os.Build.VERSION.RELEASE}\nBaterai: $level%"
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = network?.let { cm.getNetworkCapabilities(it) }
        val type = when {
            caps == null -> "Tidak terhubung"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Data seluler"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Jaringan lain"
        }
        findViewById<TextView>(R.id.networkInfo).text = "JARINGAN\nStatus: $type"
    }

    private fun requestCameraAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val selector = CameraSelector.Builder().requireLensFacing(lens).build()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder().build()
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, preview, imageCapture)
                cameraStatus.text = if (lens == CameraSelector.LENS_FACING_BACK)
                    "Preview kamera belakang aktif." else "Preview kamera depan aktif."
            } catch (e: Exception) {
                cameraStatus.text = "Kamera gagal dibuka: ${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun capturePhoto() {
        val capture = imageCapture
        if (capture == null) {
            cameraStatus.text = "Pilih Foto Belakang atau Foto Depan terlebih dahulu."
            return
        }
        val name = "SHADOW_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
        val values = android.content.ContentValues().apply {
            put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ShadowSpy")
        }
        val output = ImageCapture.OutputFileOptions.Builder(
            contentResolver,
            android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            values
        ).build()
        capture.takePicture(output, ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                    cameraStatus.text = "Foto tersimpan di Galeri/Pictures/ShadowSpy."
                }
                override fun onError(exception: ImageCaptureException) {
                    cameraStatus.text = "Gagal menyimpan foto: ${exception.localizedMessage}"
                }
            })
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun updateUsageInfo() {
        val output = findViewById<TextView>(R.id.usageInfo)
        if (!hasUsageAccess()) {
            output.text = "Akses Usage Access belum aktif. Tekan tombol izin untuk mengaktifkannya."
            return
        }
        val manager = getSystemService(USAGE_STATS_SERVICE) as android.app.usage.UsageStatsManager
        val end = System.currentTimeMillis()
        val stats = manager.queryUsageStats(
            android.app.usage.UsageStatsManager.INTERVAL_DAILY,
            end - 24L * 60L * 60L * 1000L, end
        ).orEmpty().filter { it.totalTimeInForeground > 0 }
            .sortedByDescending { it.totalTimeInForeground }.take(8)
        output.text = if (stats.isEmpty()) "Belum ada data penggunaan 24 jam terakhir."
        else "PENGGUNAAN 24 JAM TERAKHIR\n" + stats.joinToString("\n") {
            val mins = it.totalTimeInForeground / 60000
            "${it.packageName}: ${mins} menit"
        }
    }
}
